#ifndef LRT_TYPES_H
#define LRT_TYPES_H

typedef __int64_t u64;
typedef __int32_t u32;
typedef __int16_t u16;
typedef __int8_t u8;

typedef __int64_t s64;
typedef __int32_t s32;
typedef __int16_t s16;
typedef __int8_t s8;

#endif
